<?php 
     require('settings.php');
     session_start();
     unset($_SESSION['errors']); // clears any previous errors
?>

<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <meta name="author" content="Remy Amor, William Anthony, Amanuial Ashagrie">
     <meta name="description" content="Application page for Dream Team IT Solutions">
     <meta name="keywords" content="application, IT, software, software development, network, network administrator, jobs">
     <title>Dream Team IT Solutions - Apply</title>
     <!-- link to styles.css -->
     <link rel="stylesheet" href="project1/styles/styles.css">
     <link rel="stylesheet" href="styles/styles.css">

     <!-- link to responsive css -->
     <link rel="stylesheet" href="styles/responsive.css">
     <!-- <link rel="stylesheet" href="styles/aman_styles.css"> -->

</head>
<body>
     <?php include 'header.inc'; ?>
     <main>
          <h2 id="apply_header">Apply Now!</h2>
          <!-- Application form, regex pattern validation included in each form field -->
          <form action="process_eoi.php" method="POST" id="apply_form" novalidate>
               <p id="job_ref_field">
                    <label for="job_ref">Job Reference Number:</label>
                    <select name="job_ref" id="job_ref" required>
                         <!-- Change sample1 and sample2 to the actual job reference numbers -->
                         <option value="">Select a job reference number</option>
                         <?php
                              //  list of job reference numbers
                              $sql = "SELECT job_ref FROM jobs";
                              $result = mysqli_query($conn, $sql);
                              while($row = mysqli_fetch_assoc($result)) {
                                   $value = htmlspecialchars($row['job_ref']);
                                   echo "<option value='$value'>$value</option>";
                              }
                         ?>
                    </select>
               </p>
               <!-- fieldset for details -->
               <fieldset id="apply_form_fieldset">
                    <!-- below is grid div -->
                    <div class="form_grid">
                    <div class="name_and_dob">
                         <legend id="details_legend">Your Details</legend>
                         <p>
                              <label for="first_name">First Name:</label>
                              <input type="text" id="first_name" name="first_name" pattern="^[a-z]{1,20}$" required>
                         </p>
                         <p>
                              <label for="last_name">Last Name:</label>
                              <input type="text" id="last_name" name="last_name" pattern="^[a-z]{1,20}$" required>
                         </p>
                         <p>
                              <label for="date_of_birth">Date of birth:</label>
                              <input type="date" id="date_of_birth" name="date_of_birth" required>
                         </p>
                    </div>
                    <!-- nested fieldset for gender radio buttons -->
                    <div class="gender">
                         <fieldset>
                              <legend>Gender</legend>
                              <label for="male">Male</label>
                              <input type="radio" id="male" name="gender" value="male" required>
                              <label for="female">Female</label>
                              <input type="radio" id="female" name="gender" value="female" required>
                              <br>
                              <br>
                              <label for="other">Other/prefer not to say</label>
                              <input type="radio" id="other" name="gender" value="other" required>
                         </fieldset>
                    </div>
                    <div class="address_and_contact">
                         <p>
                              <label for="street_address">Street address:</label>
                              <input id="street_address" name="street_address" type="text" pattern="^\w{1,40$}" required>
                         </p>
                         <p>
                              <label for="suburb_or_town">Suburb/town:</label>
                              <input name="suburb_or_town" id="suburb_or_town" type="text" pattern="^\w{1,40$}" required>
                         </p>
                         <p id="state_and_postcode">
                              <label for="state">State:</label>
                              <select name="state" id="state" required>
                                   <option value="">Select a state</option>
                                   <option value="VIC">VIC</option>
                                   <option value="NSW">NSW</option>
                                   <option value="QLD">QLD</option>
                                   <option value="NT">NT</option>
                                   <option value="WA">WA</option>
                                   <option value="SA">SA</option>
                                   <option value="TAS">TAS</option>
                                   <option value="ACT">ACT</option>
                              </select>
                              <div>
                                   <label for="post_code" id="postcode_label">Postcode:</label>
                                   <input type="text" name="post_code" id="post_code" placeholder="xxxx" pattern="^\d{4}$" required>
                              </div>
                         </p>
                         <p id="form_contact">
                              <label for="email">Email address:</label>
                              <input type="email" id="email" name="email" placeholder="exampleemailaddress@gmail.com" required>
                              <div>
                                   <label for="phone_number" id="phone_number_label">Phone number:</label>
                                   <input type="text" id="phone_number" name="phone_number" placeholder="xxxx xxx xxx" pattern="^(\d| ){8,12}$" required>
                              </div>
                         </p>
                    </div>
                    <div class="apply_skills">
                         <fieldset>
                              <legend id="technical-skills-legend">Technical Skills</legend>
                              <fieldset>
                                   <legend>Network Administration Skills</legend>
                                   <p>
                                        <label for="cloud_technologies">Working with cloud technologies (AWS, Azure, Google Cloud)</label>
                                        <input type="checkbox" name="skills[]" id="cloud_technologies" value="cloud_technologies">
                                   </p>
                                   <p>
                                        <label for="network_diagnostics">Network diagnostic and troubleshooting skills</label>
                                        <input type="checkbox" name="skills[]" id="network_diagnostics" value="network_diagnostics">
                                   </p>
                                   <p>
                                        <label for="network_security">Network security protocols</label>
                                        <input type="checkbox" name="skills[]" id="network_security" value="network_security">
                                   </p>
                                   <p>
                                        <label for="network_configuration">Network configuration practices</label>
                                        <input type="checkbox" name="skills[]" id="network_configuration" value="network_configuration">
                                   </p>
                              </fieldset>
                              <fieldset>
                                   <legend>Software Development Skills</legend>
                                   <p>
                                        <label for="programming">Programming languages (C/C++, JS, Java)</label>
                                        <input type="checkbox" name="skills[]" id="programming" value="programming">
                                   </p>
                                   <p>
                                        <label for="version_control">Version control (i.e. git)</label>
                                        <input type="checkbox" name="skills[]" id="version_control" value="version_control">
                                   </p>
                                   <p>
                                        <label for="database_management">Database management (SQL, NoSQL)</label>
                                        <input type="checkbox" name="skills[]" id="database_management" value="database_management">
                                   </p>
                                   <p>
                                        <label for="development_lifecycle">Software development lifecycle (agile methodologies, TDD)</label>
                                        <input type="checkbox" name="skills[]" id="development_lifecycle" value="development_lifecycle">
                                   </p>
                              </fieldset>
                         </fieldset>
                    </div>
                    <!-- Technical skills list were created using chatGPT with the following prompt: "Generate a list of technical skills you would need to be a network administrator or software developer" -->
                    <div class="apply_other_skills">
                         <p>
                              <label for="other_skills">Other Skills:</label>
                              <br>
                              <textarea name="other_skills" id="other_skills" placeholder="List other skills here"></textarea>
                         </p>
                    </div>
               </div>
               </fieldset>
               <div class="submit_button">
                    <input type="submit" value="Apply" id="form_apply_button">
               </div>
          </form>
     </main>
     <?php include 'footer.inc'; ?>
</body>
</html>
